function hitungNilai() {
    let nama = document.getElementById("nama").value.trim();
    let kelas = document.getElementById("kelas").value;
    let jurusan = document.getElementById("jurusan").value;
    let tugasStr = document.getElementById("tugas").value;
    let utsStr = document.getElementById("uts").value;
    let uasStr = document.getElementById("uas").value;

    let peringatanDiv = document.getElementById("peringatan");
    if (peringatanDiv) peringatanDiv.remove();

    if (!nama || !kelas || !jurusan || !tugasStr || !utsStr || !uasStr) {
        tampilkanPeringatan("Mohon lengkapi semua data dan nilai terlebih dahulu!");
        return;
    }

    let tugas = parseFloat(tugasStr);
    let uts = parseFloat(utsStr);
    let uas = parseFloat(uasStr);

    if (isNaN(tugas) || isNaN(uts) || isNaN(uas)) {
        tampilkanPeringatan("Nilai tugas, UTS, dan UAS harus berupa angka!");
        return;
    }

    function tampilkanPeringatan(pesan) {
        const form = document.getElementById("nilaiForm");
        const div = document.createElement("div");
        div.id = "peringatan";
        div.className = "alert alert-warning text-center mt-2";
        div.innerText = pesan;
        form.parentNode.insertBefore(div, form.nextSibling);
    }

    let nilaiAkhir = (tugas * 0.3) + (uts * 0.3) + (uas * 0.4);
    let status = (nilaiAkhir >= 70) ? "KKM" : "Tidak KKM";

    document.getElementById("outNama").innerText = nama;
    document.getElementById("outKelas").innerText = kelas;
    document.getElementById("outJurusan").innerText = jurusan;
    document.getElementById("outNilai").innerText = nilaiAkhir.toFixed(2);
    document.getElementById("outStatus").innerText = status;

    document.getElementById("hasil").style.display = "block";
}
