function konversi() {
	const meterInput = document.getElementById("inputMeter").value;
	const satuan = document.getElementById("satuan").value;
	const hasilDiv = document.getElementById("hasil");

	// Validasi input
	if (meterInput === "" || meterInput === null) {
		hasilDiv.style.display = "block";
		hasilDiv.innerHTML = "⚠️ Silakan masukkan angka meter!";
		return;
	}

	const meter = Number(meterInput);
	if (isNaN(meter) || meter <= 0) {
		hasilDiv.style.display = "block";
		hasilDiv.innerHTML = "⚠️ Masukkan angka meter yang valid dan lebih dari 0!";
		return;
	}

	let hasil = null;
	let satuanText = "";
	switch (satuan) {
		case "km": hasil = meter / 1000; satuanText = "Kilometer (km)"; break;
		case "cm": hasil = meter * 100; satuanText = "Centimeter (cm)"; break;
		case "mm": hasil = meter * 1000; satuanText = "Milimeter (mm)"; break;
		case "mil": hasil = meter / 1609.344; satuanText = "Mil (mile)"; break;
		case "inci": hasil = meter * 39.3700787; satuanText = "Inci (inch)"; break;
		default:
			hasilDiv.style.display = "block";
			hasilDiv.innerHTML = "⚠️ Satuan tidak dikenali!";
			return;
	}

	hasilDiv.style.display = "block";
	hasilDiv.innerHTML = `📏 <b>${meter}</b> meter = <b>${hasil.toLocaleString(undefined, {maximumFractionDigits: 4})}</b> <span>${satuanText}</span>`;
}
